import firebase_admin
from firebase_admin import credentials, auth
from firebase_admin import db






#"\nPress 0 to exit \nPlease enter now:"
#######################################init#####################################################################

cred = credentials.Certificate("finantialtrackingtote-firebase-adminsdk.json")

# Fetch the service account key JSON file contentscred = credentials.Certificate("key")# Initialize the app with a service account, granting admin privileges
#default_app = firebase_admin.initialize_app(cred, {'databaseURL': 'https://finantialtrackingtote.firebaseio.com/'})

firebase_admin.initialize_app(cred, {'databaseURL': 'https://finantialtrackingtote.firebaseio.com/','databaseAuthVariableOverride': {'uid': '1izu1u6DIqbwpG7jCkQ3msiugP23'}})
# As an admin, the app has access to read and write all data, regradless of Security Rules
refAccount = db.reference('Account')


#####################################managers functions########################################################
def readAllAccounts():
    print(refAccount.get())


def listAllUsers():
    # Iterate through all users. This will still retrieve users in batches,
    # buffering no more than 1000 users in memory at a time.
    #for user in auth.list_users().iterate_all():
    page = auth.list_users()
    while page:
        for user in page.users:
            refUser = refAccount.child(user.uid)
            print('User: ' + user.uid + "\n  email: " + user.email )
            try:
                print("  password: " + refUser.child('Password').get())
                print("  city: " + refUser.child('City').get())
                print("  first name: " + refUser.child('FirstName').get())
                print("  last name: " + refUser.child('LastName').get())
                print("  phone number: " + refUser.child('PhoneNumber').get())
            except:
                print("COULDNT GET ACCOUNT OF USER PROBABLY SOMEONE ERASEDMANUALLY AN ACCOUNT WITH OUT ERASING USER " + user.uid)

                    #+ "\n  city: " + refUser.child('City').get())
        # Get next batch of users.
        page = page.get_next_page()




def deleteUser(_user):
    auth.delete_user(_user)
    refAccount.child(_user).delete()
    print('erased '+ _user)

def createUserAccount():
    _email = input("enter email: ")
    password = input("enter password: ")
    _number = input("enter phone number: ")
    city = input("enter city: ")
    street = input("enter street: ")
    firstName = input("enter first name: ")
    lastName = input("enter last name: ")
    isManager = int(input("enter 1 if manager: "))
    if (isManager is 1):
        isManager = 'True'
    else:
        isManager = 'False'
    user = auth.create_user(
          email=_email,password=password)
    print ('Sucessfully created new user: {0}'.format(user.uid))
    refAccount.child(user.uid).set({
        'City': city,
        'Email': _email,
        'FirstName': firstName,
        'LastName': lastName,
        'Password': password,
        'PhoneNumber': _number,
        'Street': street,
        'isManager': isManager
    }
)


def changeAttribute(uid):
    todo = int(input("\n  Press 1 to change email for user "
                     "\n  Press 2 for changing phone number for user "
                     "\n  Press 3 for changing password for user "))
    if (todo is 1):
        value = input('    enter new email ')
        #key = 'email'
        user = auth.update_user(uid, email=value)
        print('Sucessfully updated user: {0}'.format(user.uid))
        refAccount.child(uid).child('email').set(value)
    if (todo is 2):
        value = input('    enter new phoneNumber ')
        try:
            user = auth.update_user(uid, phone_number=value)

            print('Sucessfully updated user: {0}'.format(user.uid))
        except:
            print("did not change in auth.")

        try:
            refAccount.child(uid).child('PhoneNumber').set(value)
            print("changed in Account")
        except:
            print("did not change in account")

    if (todo is 3):
        value = input('    enter new password ')
        user = auth.update_user(uid, password=value)
        print('Sucessfully updated user: {0}'.format(user.uid))
        refAccount.child(uid).child('password').set(value)
    else:
        refAccount.child(uid).child(key).set(value)
###############################################program running: ##########################################
todo = -1

while(todo is not 0):
    try:
        todo = int(input("\n\nPress 1 to get all accounts"
              "\nPress 2 for creating a new user "
              "\nPress 3 for deleting user"
              "\nPress 4 to change an attribute "
              "\nPress 0 to exit \n\nPlease enter now:"))
    except:
        print("      You did not enter a number")
        todo = -1
    if(todo is 1):
        #readAllAccounts()
        listAllUsers()
    if(todo is 2):
        try:
            createUserAccount()
        except:
            print("something went wrong ")
    if(todo is 3):
        uid = input('enter uid to delete: ')
        deleteUser(uid)
    if(todo is 4):
        uid = input(' enter uid of account to change ')
        try:
            changeAttribute(uid)
        except:
            print("\nSomething went wrong with uid or key")